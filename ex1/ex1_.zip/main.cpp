#include <iostream>
#include "osm.cpp"

int main ()
{

  osm_function_time (10);
  osm_operation_time (10);
  osm_syscall_time (10);
}
